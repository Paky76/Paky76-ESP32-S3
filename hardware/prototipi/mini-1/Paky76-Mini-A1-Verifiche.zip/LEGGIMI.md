# Paky76 Mini A1 — Verifiche per il prototipo

## Batteria e USB

La scheda tecnica PKCell della batteria Adafruit 2750 riporta 350 mA massimi di carica e 525 mA massimi di scarica continua. Il limite di scarica continua non dimostra l'idoneità ai picchi. Con tensione cella 3,0 V e rendimento assunto all'85%, una richiesta di 400 mA a 3,3 V richiede circa 518 mA alla batteria prima delle perdite nel power path. A 500 mA sul rail servono circa 647 mA. La combinazione va qualificata sia a batteria carica sia a fine scarica. In caso di superamento, adottare una cella con corrente di scarica documentata maggiore oppure ridurre il carico e ripetere le misure. Il limite di scarica non va dedotto dalla sola capacità.

Per BQ24074, TI documenta RISET 590 Ω–8,9 kΩ e KISET tipico 890 AΩ. 8,87 kΩ 0,1% dà circa 100 mA nominali ed evita di eccedere 8,9 kΩ con la tolleranza del resistore. I 100 mA di limite USB e i 100 mA di corrente di carica sono impostazioni diverse. Prima della configurazione USB il sistema e il caricatore condividono il limite d'ingresso. Con USB collegata e batteria scollegata occorre dimostrare che il processore riesce ad avviarsi ed enumerare entro il limite iniziale, altrimenti va specificata una modalità di servizio con batteria o una gestione separata della disponibilità della sorgente. Validare soglie TS e posizione fisica NTC nella scocca.

## Sequenza per la fabbricazione

1. Verifica meccanica con USB, OLED, connettori accoppiati e tasti fisici. Il modulo Waveshare impiega un connettore a sette pin e configurazione del bus, mentre il frontale prevede quattro linee per il collegamento I²C. Il cablaggio e gli strap/reset del modulo devono essere qualificati prima dell'approvazione.
2. Completare schema e PCB della principale e confrontare lo schema con il PCB frontale. Verificare regole elettriche, keepout radio, integrità USB e dissipazione. Il modulo radio sul bordo alto della principale richiede separazione da display, batteria e occhiello metallico. Bloccare le quote dopo prova d'ingombro con la componentistica reale.
3. Generare due set Gerber/forature, BOM e CPL, controllare rotazioni, tipo PCBA, lato e disponibilità nell'anteprima JLCPCB. Il catalogo pubblico identifica i codici, la disponibilità per ordine è distinta. Lo stock va verificato al momento del preventivo.
4. Sul primo esemplare misurare correnti, temperatura e comportamento con USB collegata e scollegata, batteria quasi scarica, Wi-Fi attivo e transizioni di carica. Verificare meccanicamente la ritenzione della batteria e il distacco da viti/spigoli. Queste prove fisiche seguono la fabbricazione del primo campione e precedono qualunque lotto.

## Fonti

- Cella PKCell 350 mAh: https://www.mouser.com/datasheet/2/737/Adafruit%20Industries_03062018_2750-1310803.pdf
- Caricatore: https://www.ti.com/lit/ds/symlink/bq24074.pdf
- Regolatore: https://www.ti.com/product/TPS63070
- Display di riferimento: https://www.waveshare.com/wiki/1.3inch_OLED_(B)
- Capacità assemblaggio: https://jlcpcb.com/capabilities/pcb-assembly-capabilities

## Risultati frontale A1

- Frontale da 43 × 42 mm, due strati, tasti laterali EVQP7A01P, J1 a sei vie verso principale e J2 a quattro vie verso il display. I pulsanti cortocircuitano a massa i corrispondenti segnali quando premuti. I pull-up vanno sulla principale.
- Cablaggio J1: 1 GND, 2 3V3, 3 SDA, 4 SCL, 5 LEFT_N, 6 RIGHT_N. J2: 1 GND, 2 3V3, 3 SDA, 4 SCL. Il frontale deve essere orientato fisicamente con gli attuatori verso le pareti. Verificare quale tasto è a sinistra guardando il display dopo il montaggio.
- KiCad 9.0.2: zero violazioni ERC/DRC, zero piazzole scollegate e zero discrepanze schema/PCB. Il contorno Gerber corrisponde al modello A0. Il CAM locale e la corrispondenza BOM/CPL sono registrati in Verifiche.
- Gli export del frontale sono per revisione CAM. Il display è esterno al frontale e non compare nella BOM di assemblaggio. Il montaggio del modulo con i relativi cavi e la geometria degli attuatori devono ancora essere verificati con componenti reali e scocca. Per la principale sono disponibili le dime A0 e le verifiche di selezione qui documentate. Schema, routing e pacchetto d'ordine della principale restano aperti. Nessun ordine inviato.
- Simboli e footprint distribuiti con il progetto provengono dalle librerie KiCad, licenza CC BY-SA 4.0 con eccezione KiCad: https://www.kicad.org/libraries/license/
