# Paky76 Mini A0 — Prototipo di ingombro e specifica elettronica

Il formato deriva dai tre video allegati. Nel primo si vede il montaggio di una XIAO ESP32-S3, un OLED collegato a fili, una batteria a sacchetto e un interruttore. Il secondo illustra l'uso a due tasti e le animazioni. Il terzo mostra la costruzione della scocca e l'aggancio. La quota di 37 mm visibile nel CAD è locale. Le dimensioni dell'involucro qui sotto sono quote di progetto Paky76.

La Rev.H/D3 è il riferimento per ESP32-S3, USB nativa e convenzioni firmware. La CR1220 alimenta il backup RTC. La Mini sostituisce display, pannello a cinque tasti e alimentazione di sistema. Per la prima versione si assume funzionamento autonomo con animazioni e due tasti. Audio, camera, microSD, LTE e RTC con batteria dedicata restano fuori dalla Mini A0. I sorgenti della Rev.H non sono stati modificati.

## Prova con la Sidewinder X1

| File | Scopo | Ingombro |
| --- | --- | --- |
| Meccanica/tray.stl | Guscio posteriore, passaggio USB-C e occhiello | 48 × 54,5 × 15 mm, occhiello incluso |
| Meccanica/bezel.stl | Cornice con finestra OLED e passaggi laterali per due comandi | 48 × 47 × 5 mm |
| Meccanica/main_gauge.stl | Dima scheda principale | 32 × 39 × 1,6 mm |
| Meccanica/front_gauge.stl | Dima scheda frontale | 43 × 42 × 1,6 mm |
| Meccanica/cell_gauge.stl | Dima batteria, esclusi cavi e connettore | 37 × 21 × 6 mm |

Carica gli STL in Cura al 100%, con il vassoio appoggiato sul fondo e la cornice appoggiata sulla faccia esterna. Per la prova, usa un profilo PLA con layer da 0,20 mm. Verifica il ponte sopra la porta USB-C ed eventualmente usa supporto localizzato. Altezza complessiva nominale 20 mm. Il modello OpenSCAD parametrico contiene l'assieme. Controlla accesso al cavo, corsa dei due tasti, distanza da viti e spigoli e volume dei cablaggi. L'OLED di riferimento per l'ingombro è Waveshare SH1106 128×64 da 40,5 × 37,5 mm. Usare il pezzo reale per centrare la finestra e stabilire montaggio, altezza del connettore e interferenze. Il modulo completo è un riferimento per la prova. La distinta della scheda frontale richiede un OLED con codice, geometria e footprint approvati.

Il vassoio è una dima. La sede batteria con ritenzione, la separazione dalla scheda, gli attuatori e la resistenza dell'occhiello vanno definiti dopo la prova. Usa esclusivamente il simulacro stampato per questa verifica.

## Architettura delle due schede

| Scheda | Contenuto | Ipotesi per assemblaggio |
| --- | --- | --- |
| Principale | ESP32-S3-WROOM-1-N16R8, USB-C dati e ricarica, protezione ESD, caricatore con power path, buck-boost 3,3 V, ingresso batteria, enable, BOOT/RESET | 4 strati, un lato di montaggio, tenere distinta la zona RF |
| Frontale | OLED monocromatico SH1106, due pulsanti a comando laterale, disaccoppiamento e connettore | 2 strati, un lato di montaggio. Se il display non è assemblabile da JLCPCB, va montato a parte sul prototipo |

Interfaccia proposta a sei vie, da verificare sul pinout finale: 1 GND, 2 3V3, 3 SDA/GPIO21, 4 SCL/GPIO47, 5 LEFT_N/GPIO4, 6 RIGHT_N/GPIO5. Tasti attivi bassi con pull-up sulla principale. Pull-up I²C in una sola posizione effettiva, inclusi eventuali pull-up del display. Verificare l'orientamento e il pin 1 a entrambi i capi. GPIO19/20 restano dedicati alla USB nativa. Conservare la configurazione BOOT/RESET e verificare l'enumerazione. Base firmware prevista: occhi animati, menu con due tasti e spegnimento dello schermo per inattività. Per standby profondo verificare GPIO di risveglio e condizioni del display.

## Alimentazione e ricarica

USB-C 5 V → protezione ingresso → BQ24074 (IN). Una cella LiPo 1S protetta, nominale 3,7 V e fine carica 4,2 V, va a BAT. OUT alimenta il buck-boost TPS63070 candidato, regolato a 3,3 V. L'interruttore comanda l'abilitazione del regolatore: si può spegnere il dispositivo lasciando attiva la carica. Collegare USB D−/D+ a GPIO19/20 con protezione ESD e layout conforme. Configurare la presa come sink USB-C con terminazioni Rd separate e dimensionare il limite d'ingresso in base alla corrente effettivamente autorizzata dalla sorgente. Verificare le modalità PC e alimentatore USB, la corrente prima della configurazione, l'avvio con batteria assente e la commutazione durante l'uso. La carica può rallentare quando il carico assorbe corrente.

Riferimento per ingombro: Adafruit 2750, 350 mAh, 36 × 19,6 × 5,2 mm. Verificare sul pacco definitivo protezione, polarità, corrente di scarica continua e di picco, temperatura e corrente di carica da scheda tecnica. Con pacco a due fili prevedere sensore NTC termicamente accoppiato alla cella compatibile con TS e provare i limiti. Corrente obiettivo iniziale 100 mA, subordinata alla specifica del pacco, alle tolleranze del circuito e al collaudo termico. Prevedere soglia di spegnimento prima dell'intervento della protezione della cella. Misurare caduta e picchi sul sistema a batteria quasi scarica, poi approvare il regolatore e la capacità. Separare da antenna i conduttori, la cella e il display con il keepout raccomandato da Espressif.

Autonomia indicativa: 350 mAh × 3,7 V × 0,8 di efficienza × 0,8 di capacità utilizzabile ≈ 0,83 Wh. A 3,3 V e 50 mA medi sul rail equivale a circa 5 ore; a 100 mA circa 2,5 ore. Sono stime di progetto riferite alla corrente media, con Wi-Fi e luminosità da misurare.

## Consegna JLCPCB

I due file KiCad sono contorni e fori di fissaggio M2, con origine geometrica a X100/Y100 mm. Il DRC KiCad 9.0.2 riporta zero violazioni per questi soli contorni. Gli STL sono stati esportati e verificati come mesh chiuse. Il pacchetto è utilizzabile per la prova di ingombro. Per l'ordine servono schemi, componenti, routing e verifiche ERC/DRC elettriche. Da questi vanno esportati due set distinti di Gerber e forature, BOM con MPN/LCSC e CPL con XY, lato e rotazioni.

JLCPCB indica 10 × 10 mm come minimo Economic per una PCB singola e 70 × 70 mm per Standard. Valutare Economic per entrambe se il montaggio resta su un lato e macchina, footprint, componenti e finitura sono compatibili. In caso di Standard concordare la pannellizzazione con JLCPCB. La batteria si installa dopo l'assemblaggio e il collaudo elettrico.

Per approvare l'ordine occorrono prova con componenti reali, controllo dello stack-up e del keepout RF, disponibilità componenti, e verifica dell'anteprima PCBA per riferimenti, orientamento e lato. Sul primo campione misurare 3,3 V con oscilloscopio durante avvio/Wi-Fi, corrente di carica, gestione NTC, temperature con scocca chiusa, assorbimento da spento e autonomia. Verificare inserimento/rimozione USB, funzionamento con e senza batteria, LED di stato se previsto e recupero dopo batteria scarica.

## Riferimenti

- TI BQ24074: https://www.ti.com/product/BQ24074
- TI TPS63070: https://www.ti.com/product/TPS63070
- Espressif ESP32-S3 hardware guidelines: https://docs.espressif.com/projects/esp-hardware-design-guidelines/en/latest/esp32s3/
- Waveshare OLED 1.3 B: https://www.waveshare.com/wiki/1.3inch_OLED_(B)
- Adafruit 2750: https://www.adafruit.com/product/2750
- JLCPCB PCBA: https://jlcpcb.com/capabilities/pcb-assembly-capabilities
