# Paky76 Mini A2 — Primo prototipo, file per preventivo JLCPCB

## Cosa è cambiato

La scheda principale ora usa la Seeed Studio XIAO ESP32-S3 113991114, la stessa famiglia mostrata nei video. Il modulo integra USB-C, programmazione USB, regolatore e caricatore LiPo 1S. Il PCB principale è un carrier a due strati, con il connettore e i pull-up I²C. Questa revisione sostituisce la proposta di montare il WROOM, il BQ24074 e il TPS63070 sulle schede Paky76. Il frontale A1 rimane compatibile con la stessa interfaccia a sei vie e usa due tasti laterali.

## Preventivo JLCPCB

| Cartella | Contorno | Strati | PCBA |
| --- | --- | ---: | --- |
| JLCPCB/Principale | 32 × 39 mm | 2 | Economic, componenti lato Top, tre riferimenti |
| JLCPCB/Frontale | 43 × 42 mm | 2 | Economic, componenti lato Top, quattro riferimenti |

Per ciascuna scheda caricare lo ZIP Gerber del relativo gruppo, poi BOM e CPL nella pagina PCB Assembly. Specifica iniziale 1,6 mm, FR-4, rame esterno 1 oz. Selezionare la quantità minima di PCBA proposta dal configuratore per il primo prototipo. Verificare i contorni, i codici e la disponibilità per la quantità scelta, il pin 1 dei JST e il verso degli attuatori di SW1/SW2. Guardando il lato componenti, gli attuatori devono puntare verso i bordi laterali opposti. Approvare il CAM solo dopo aver confrontato la vista JLCPCB con KiCad. La consegna include due set distinti. J2 e J3 della principale sono due file di fori metallizzati per il montaggio manuale del modulo.

## Materiale da procurare per ogni dispositivo

- 1 Seeed Studio XIAO ESP32-S3 standard 113991114 con antenna del modulo. Usare due file di pin maschi 1×7 da 2,54 mm a profilo basso. Una soluzione a zoccolo rialza la USB-C e richiede di adeguare il guscio.
- 1 LiPo protetta 1S da 350 mAh con fine carica 4,2 V. Riferimento dimensionale Adafruit 2750, 36 × 19,6 × 5,2 mm. Confermare polarità e compatibilità con il caricatore della revisione di XIAO ricevuta. Acquistare una controparte a cavo compatibile con il connettore della batteria.
- 1 OLED SH1106 128×64 a 3,3 V configurato I²C, più cablaggio. Il modulo di riferimento per l'ingombro è Waveshare 10451, 40,5 × 37,5 mm. Su quello specifico modulo verificare gli strap per I²C, l'indirizzo, lo stato di CS/D-C e la gestione del reset secondo istruzioni Waveshare. Il suo connettore a sette pin richiede un cablaggio adattato e può incidere sull'altezza. Prima dell'ordine verificare il montaggio e l'accesso a viti e cavi con il modulo previsto.
- 1 cavo JST SH a sei vie passo 1,0 mm tra le due schede. Verificare la continuità pin 1→1 fino a 6→6 con il multimetro.
- 1 cavetto JST SH a quattro vie lato frontale da adattare all'OLED, 8 viti M2 di lunghezza selezionata in base alle sedi e un anello portachiavi. Stampare prima la scocca di prova.

## Montaggio e collaudo

1. Stampare il guscio e la cornice al 100% in Cura e usare le dime. Ingombro di prova 48 × 47 × 28 mm, escluso l'occhiello. Verificare apertura USB con il cavo reale, allineamento dei tasti, altezza OLED, antenna, cablaggi, spazio per il modulo e sede della cella. Il modello è una prova di ingombro. Attuatori, fissaggio display e ritenzione cella richiedono verifica meccanica. Tenere la cella separata da componenti, saldature, viti e spigoli. Per la prova di montaggio usare la dima, senza installare la cella.
2. Saldare a modulo scollegato un cavetto isolato ai pad BAT+ e BAT− della XIAO seguendo la marcatura Seeed. Usare un connettore intermedio e verificare con il multimetro la polarità su entrambi i lati prima di accoppiare. La batteria non transita dai pin 5V e 3V3 della carrier. Montare il modulo con USB verso l'apertura, lasciando spazio per cavo batteria e antenna. Evitare che la cella sostenga la pressione della scocca e proteggere i collegamenti con ritenzione meccanica.
3. Accendere inizialmente con USB e senza batteria. Verificare enumerazione, tensione sui pin J1 del frontale e assorbimento anomalo. Collegare il frontale e successivamente l'OLED. J1 pin 1–6: GND, 3V3, SDA GPIO5, SCL GPIO6, LEFT_N GPIO2, RIGHT_N GPIO1. J2 frontale pin 1–4: GND, 3V3, SDA, SCL. Un pulsante premuto deve portare a massa la relativa linea. I pull-up I²C sono 4,7 kΩ sulla principale, misurare la resistenza effettiva se presenti anche sul display.
4. Caricare lo sketch con target Seeed Studio XIAO ESP32S3. Lo sketch di collaudo prova il display SH1106, i due comandi, il lampeggio degli occhi e lo spegnimento del display dopo inattività. Verifica di sintassi C++ eseguita con interfacce simulate. Compilazione nel core Arduino ESP32 e prova su scheda restano da fare. Il firmware non abilita il Wi-Fi e il timer spegne solo il display. La A2 non ha un comando fisico di spegnimento o un modo deep sleep qualificato.
5. Collegare la cella dopo le misure USB. Verificare corrente di carica reale e tensione finale con strumentazione, comportamento a batteria e con USB inserita o rimossa, temperatura e autonomia. Ripetere a batteria parzialmente scarica. Controllare l'assenza di riavvii e che la corrente rimanga entro i limiti della cella. La 350 mAh di riferimento documenta 525 mA continui. Conservare Wi-Fi disabilitato per il primo collaudo e qualificare eventuali picchi radio sulla batteria prima di abilitarlo. La ricarica della XIAO è integrata, priva di sensore di temperatura esterno su questa carrier. Usare solo il pacco qualificato, entro le temperature definite dal suo produttore, e validare la carica in scocca prima dell'uso regolare.
6. Solo dopo aver verificato il prototipo, consolidare la scocca e il cablaggio e autorizzare un lotto.

## Verifiche eseguite

- Sorgenti KiCad 9, ERC e DRC con parità schema/PCB per entrambe le schede. Zero violazioni e zero connessioni mancanti.
- Verifiche locali dei contorni Gerber, numero dei fori PTH/NPTH, riferimenti e montaggio su un lato. STL verificati come mesh chiuse. I file di produzione della principale includono 14 fori da 1,00 mm per il modulo.
- Il CAM del configuratore JLCPCB, lo stock del preventivo, le prove elettriche, di ricarica e di montaggio richiedono verifica. Nessun invio di ordine o pagamento.

## Riferimenti

- Seeed XIAO ESP32-S3: https://wiki.seeedstudio.com/xiao_esp32s3_getting_started/
- Schema Seeed revisione 1.3: https://files.seeedstudio.com/wiki/SeeedStudio-XIAO-ESP32S3/res/XIAO_ESP32S3_V1.3_SCH_260115.pdf
- Batteria: https://www.adafruit.com/product/2750
- Display: https://www.waveshare.com/wiki/1.3inch_OLED_(B)
- JLCPCB PCBA: https://jlcpcb.com/capabilities/pcb-assembly-capabilities
- Simboli e footprint KiCad: https://www.kicad.org/libraries/license/
