# Paky76 Rev.G / D2.1 — File di fabbricazione e assemblaggio

Sono due ordini PCB distinti. Usa i file della cartella del fornitore scelto. Carica il Gerber ZIP del singolo PCB e abbina BOM e piazzamenti della stessa scheda.

| Scheda | Dimensioni finite | Strati | Montaggio | Piazzamenti |
| --- | --- | --- | --- | --- |
| Principale | 83,25 × 42 mm | 4 | Top + Bottom | 43, oppure 42 con BT1 da saldare a mano |
| Pannello comandi | 34 × 34 mm | 4 | Top | 17, inclusi cinque ALPS SKQGABE010 |

- **PCBWay**. Scegli Turnkey, Both sides sulla principale e Top side sul pannello. Usa le sottocartelle `Principale` e `Pannello`. La nota `PCBWay/PREVENTIVO.md` contiene il testo da allegare per ottenere schede singole già depannellizzate.
- **JLCPCB**. Scegli Standard PCBA, Top + Bottom per la principale. In `Principale` scegli una sola coppia BOM/CPL: `Completa` o `BT1-Manuale`. Lo slot J9 è incluso in entrambe. Per il pannello usa la BOM C115351 e il CPL nella stessa cartella con assemblaggio Top; il servizio disponibile si verifica nel carrello.
- **Prima di confermare**. Verifica nel CAM quote finali, orientamenti, disponibilità e consegna di schede singole con eventuali guide rimosse. La scocca D2.1 accetta i contorni finiti riportati sopra.
- **Dopo la consegna**. Stampa `Scocca-D2.1`, segui i PDF in `Documenti` e usa il documento di cablaggio per collegare i moduli esterni. Il firmware applicativo e il collaudo fisico sono ancora da completare.
